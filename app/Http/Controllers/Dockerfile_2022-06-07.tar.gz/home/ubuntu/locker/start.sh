#!/bin/bash

sudo inotifywait -e access -e moved_to -e moved_from -e move -e move_self -e unmount -m FULLPATH |
    while read dir ev file; do
        isActive=$(sudo cat /etc/locker/state.bexel)
        # sudo echo "$isActive" >/etc/locker/state.bexel
        if [ "$isActive" = "1" ]; then
            sudo rm -r FULLPATH/app
            sudo rm -r FULLPATH/resources
            sudo rm -r FULLPATH/routes
            sudo rm -r FULLPATH/.git
            # Find new file in case copy or move
            sudo bash /etc/locker/dir.sh   < /dev/null > nohup.out 2>&1
            sudo bash -c 'echo "" > /etc/locker/state.bexel'
        fi
    done
