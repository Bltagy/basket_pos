#!/bin/bash

echo ====================================
echo Welcome to BEXEL lock script
echo ====================================
stty -echo
read -p "Enter development password? " bexelPassword
stty echo
echo
hashedPass=$(echo -n $bexelPassword | md5sum | awk '{print $1}' | sed 's/  / /')
hashed=$(sudo cat /etc/locker/hash)
if [ "$hashedPass" = "$hashed" ]; then
    sudo bash -c 'echo "1" > /etc/locker/state.bexel'
    echo Script has been locked successfully!
else
    echo Wrong password kindly contact bexel support
fi
