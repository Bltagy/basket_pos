#!/bin/bash
echo ====================================
echo Welcome to BEXEL locker script
echo ====================================

echo installing inotify-tools..!
sudo apt install inotify-tools

echo ====================================
echo Copy the script to the file system..! 
sudo mkdir /etc/locker
sudo cp * /etc/locker
sudo chmod +x /etc/locker/*

# stty -echo
echo ====================================
read -p "Enter the fullpath of the application you want to lock? " bexelPath
# stty echo

##Check if exist
sudo sed -i "s#FULLPATH#${bexelPath}#g" /etc/locker/start.sh
sudo sed -i "s#FULLPATH#${bexelPath}#g" /etc/locker/dir.sh

# Cron
#Need Inhancement
echo ====================================
echo Setup the cron job..!
crontab cronjob
sudo crontab cronjob

# Install the commands
echo ====================================
echo Install the bexel-lock/bexel-unlock/bexel-status commands ..! 
echo alias "bexel-lock='/etc/locker/lock.sh'" >> ~/.zshrc
echo alias "bexel-unlock='/etc/locker/unlock.sh'" >> ~/.zshrc
echo alias "bexel-status='/etc/locker/status.sh'" >> ~/.zshrc


# bash -cx  "shopt -s expand_aliases"
. /home/ubuntu/.bashrc
nohup sh /etc/locker/start.sh > /dev/null 2>&1 &