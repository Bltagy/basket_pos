#!/bin/bash

echo ====================================
echo Welcome to BEXEL unlock script
echo ====================================
stty -echo
read -p "Enter development password? " bexelPassword
stty echo
echo
hashedPass=$(echo -n $bexelPassword | md5sum | awk '{print $1}' | sed 's/  / /')
hashed=$(sudo cat /etc/locker/hash)
if [ "$hashedPass" = "$hashed" ]; then
    sudo bash -c 'echo "" > /etc/locker/state.bexel'
    echo Script has been unlocked successfully!
else
    echo Wrong password kindly contact bexel support
fi
