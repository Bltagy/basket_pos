#!/bin/bash
stty -echo
read -p "Enter development password? " bexelPassword
stty echo
echo

hashedPass=$(echo -n $bexelPassword | md5sum | awk '{print $1}' | sed 's/  / /')
hashed=$(sudo cat /etc/locker/hash)
if [ "$hashedPass" = "$hashed" ]; then
    isActive=$(sudo cat /etc/locker/state.bexel)
    if [ "$isActive" = "1" ]; then
        echo Script is locked. 
    else
        echo Script is not locked. 
    fi

else
    echo Wrong password kindly contact bexel support
fi
