sudo find / -ignore_readdir_race \( -iname '*.php' \) -mmin -1 ! -path "FULLPATH/*" ! -path "/var/log/*" ! -path "/proc/*" -printf '%h\n'
                while read found; do
                    if [[ "$found" == *\/'app'* ]] || [[ "$found" == *\/'.git'* ]] || [[ "$found" == *\/'routes'* ]] || [[ "$found" == *\/'resources'* ]]; then
                        sudo rm -r $found
                    fi
                done
